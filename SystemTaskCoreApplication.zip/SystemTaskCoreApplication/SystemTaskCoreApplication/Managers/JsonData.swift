//
//  JsonData.swift
//  SystemTaskCoreApplication
//
//  Created by SMART TECHIES on 02/09/24.
//

import Foundation

let jsonData = """
[{
    "video_id": "11969446",
    "video_fk": "AEE7CBFD-66CB-2E17-53B1-81D3882C5F5D",
    "videourl": "http://d5638c46e9d8a6fde200-4a368be6a86dae998dd81c519d69c3f4.r88.cf1.rackcdn.com/AEE7CBFD-66CB-2E17-53B1-81D3882C5F5D.mp4",
    "thumbnail": "https://resources.flickfusion.net/avavids/1/clients/224/images/AEE7CBFD-66CB-2E17-53B1-81D3882C5F5D_1.jpg",
    "video_local_title": "11111",
    "video_title": "111111"
},
{
    "video_id": "11877376",
    "video_fk": "55608C1E-7E35-3E85-ED4E-A4BC250715DB",
    "videourl": "http://d5638c46e9d8a6fde200-4a368be6a86dae998dd81c519d69c3f4.r88.cf1.rackcdn.com/55608C1E-7E35-3E85-ED4E-A4BC250715DB.mp4",
    "thumbnail": "https://resources.flickfusion.net/avavids/1/clients/224/images/55608C1E-7E35-3E85-ED4E-A4BC250715DB_1.jpg",
    "video_local_title": "222222",
    "video_title": "2222222"
},
{
    "video_id": "11877234",
    "video_fk": "0F7EF302-64D1-B482-3B2F-DB69A757AAA8",
    "videourl": "http://d5638c46e9d8a6fde200-4a368be6a86dae998dd81c519d69c3f4.r88.cf1.rackcdn.com/0F7EF302-64D1-B482-3B2F-DB69A757AAA8.mp4",
    "thumbnail": "https://resources.flickfusion.net/avavids/1/clients/224/images/0F7EF302-64D1-B482-3B2F-DB69A757AAA8_1.jpg",
    "video_local_title": "333333",
    "video_title": "333333"
}]
""".data(using: .utf8)!
