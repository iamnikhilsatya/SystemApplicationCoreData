//
//  VideoResponse.swift
//  SystemTaskCoreApplication
//
//  Created by SMART TECHIES on 02/09/24.
//

import Foundation

struct Video: Decodable {
    let video_id: String
    let video_fk: String
    let videourl: String
    let thumbnail: String
    let video_local_title: String
    let video_title: String
    let lastupdate: String?
    let downloadStatus: String?
}
