//
//  VideoViewModel.swift
//  SystemTaskCoreApplication
//
//  Created by SMART TECHIES on 02/09/24.
//

import Combine
import CoreData

protocol VideoDownloadViewModelDelegate: AnyObject {
    func didUpdateDownloadProgress(videoID: String, progress: Double)
}

class VideoDownloadViewModel {
    private var cancellables = Set<AnyCancellable>()
    weak var delegate: VideoDownloadViewModelDelegate?

    private var downloadProgress: [String: Double] = [:]
    var downloadProgressPublisher = PassthroughSubject<(String, Double), Never>()

    func downloadVideo(item: Item, context: NSManagedObjectContext) {
        guard let videoURLString = item.videourl, let url = URL(string: videoURLString) else { return }
        
        let downloadTask = URLSession.shared.downloadTask(with: url) { [weak self] localURL, response, error in
            guard let self = self, let localURL = localURL else { return }
            
            do {
                let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                let destinationURL = documentsDirectory.appendingPathComponent(url.lastPathComponent)
                try FileManager.default.moveItem(at: localURL, to: destinationURL)
                
                // Update download status in Core Data
                item.downloadStatus = "Completed"
                try context.save()
                
                // Notify delegate about completion and remove progress
                DispatchQueue.main.async {
                    self.downloadProgress[item.video_id ?? ""] = nil
                    self.delegate?.didUpdateDownloadProgress(videoID: item.video_id ?? "", progress: 1.0)
                }
            } catch {
                print("Failed to move downloaded file: \(error)")
            }
        }
        
        // Observe download progress
        downloadTask.progress.publisher(for: \.fractionCompleted)
            .sink { [weak self] progress in
                guard let self = self else { return }
                let videoID = item.video_id ?? ""
                DispatchQueue.main.async {
                    self.downloadProgress[videoID] = progress
                    self.downloadProgressPublisher.send((videoID, progress))
                    self.delegate?.didUpdateDownloadProgress(videoID: videoID, progress: progress)
                }
            }
            .store(in: &cancellables)
        
        downloadTask.resume()
    }
}
