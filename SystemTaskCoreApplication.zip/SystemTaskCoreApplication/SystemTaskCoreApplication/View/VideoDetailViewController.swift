//
//  VideoDetailViewController.swift
//  SystemTaskCoreApplication
//
//  Created by SMART TECHIES on 02/09/24.
//

import UIKit
import AVKit
import CoreData

class VideoDetailViewController: UIViewController {

    var item: Item
    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var isPlaying = false

    init(item: Item) {
        self.item = item
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        view.backgroundColor = .white
        setupViews()
        setupPlayer()
    }

    private func setupViews() {
        let titleLabel = UILabel()
        titleLabel.text = item.video_title ?? "Unknown Title"
        titleLabel.font = .systemFont(ofSize: 24, weight: .bold)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        let localTitleLabel = UILabel()
        localTitleLabel.text = item.video_local_title ?? "Unknown Local Title"
        localTitleLabel.font = .systemFont(ofSize: 18)
        localTitleLabel.translatesAutoresizingMaskIntoConstraints = false

        let playButton = UIButton(type: .system)
        playButton.setTitle(isPlaying ? "Pause Video" : "Play Video", for: .normal)
        playButton.addTarget(self, action: #selector(playButtonTapped), for: .touchUpInside)
        playButton.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(titleLabel)
        view.addSubview(localTitleLabel)
        view.addSubview(playButton)

        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            localTitleLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 10),
            localTitleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            playButton.topAnchor.constraint(equalTo: localTitleLabel.bottomAnchor, constant: 20),
            playButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])
    }

    private func showVideoUnavailableMessage() {
        let alertController = UIAlertController(title: "Error", message: "Video is not available", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }

    
    private func setupPlayer() {
        guard item.downloadStatus == "Completed",
               let videoUrlString = item.videourl,
               let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
             showVideoUnavailableMessage()
             return
         }

        let videoURL = documentsDirectory.appendingPathComponent(URL(string: videoUrlString)?.lastPathComponent ?? "")
        player = AVPlayer(url: videoURL)
        
        // Create and configure the player layer
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.videoGravity = .resizeAspect
        playerLayer?.frame = CGRect(x: 0, y: 200, width: view.frame.width, height: 300) // Adjust the frame as needed
        if let playerLayer = playerLayer {
            view.layer.addSublayer(playerLayer)
        }
    }

    @objc private func playButtonTapped(_ sender: UIButton) {
        if isPlaying {
            player?.pause()
        } else {
            player?.play()
        }
        isPlaying.toggle()
        sender.setTitle(isPlaying ? "Pause Video" : "Play Video", for: .normal)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Update the frame if needed when the view's layout changes
        playerLayer?.frame = CGRect(x: 0, y: 200, width: view.frame.width, height: 300) // Adjust the frame as needed
    }
}
