//
//  VideoListViewController.swift
//  SystemTaskCoreApplication
//
//  Created by SMART TECHIES on 02/09/24.
//

import UIKit
import CoreData
import Combine

class VideoListViewController: UITableViewController {

    private var items: [Item] = []
    private var downloadProgress: [String: Double] = [:]
    private var viewModel = VideoDownloadViewModel()
    private var cancellables = Set<AnyCancellable>()
    private var context: NSManagedObjectContext

    init(context: NSManagedObjectContext) {
        self.context = context
        super.init(style: .plain)
        fetchItems()
        setupBindings()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "VideoCell")
    }

    private func fetchItems() {
        let fetchRequest: NSFetchRequest<Item> = Item.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "video_id", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]

        do {
            items = try context.fetch(fetchRequest)
            tableView.reloadData()
        } catch {
            print("Failed to fetch items: \(error)")
        }
    }

    private func setupBindings() {
        viewModel.downloadProgressPublisher
            .sink { [weak self] videoID, progress in
                self?.downloadProgress[videoID] = progress
                self?.updateCellProgress(videoID: videoID, progress: progress)
            }
            .store(in: &cancellables)
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let item = items[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "VideoCell", for: indexPath)

        // Reset cell's accessory view and text label
        cell.accessoryView = nil
        cell.detailTextLabel?.text = nil
        
        // Configure cell text
        cell.textLabel?.text = item.video_title

        if item.downloadStatus == "Completed" {
            cell.detailTextLabel?.text = "Download Completed"
        } else {
            if let progress = downloadProgress[item.video_id ?? ""] {
                let progressView = UIProgressView(progressViewStyle: .default)
                progressView.progress = Float(progress)
                cell.accessoryView = progressView
            } else {
                let downloadButton = UIButton(type: .system)
                downloadButton.frame = CGRect(x: 0, y: 0, width: 100, height: 30) // Example frame, adjust as needed
                downloadButton.setTitle("Download", for: .normal)
                downloadButton.setTitleColor(.white, for: .normal)
                downloadButton.backgroundColor = .blue
                downloadButton.layer.cornerRadius = 16
                downloadButton.addTarget(self, action: #selector(downloadButtonTapped(_:)), for: .touchUpInside)
                cell.accessoryView = downloadButton

            }
        }

        return cell
    }

    @objc private func downloadButtonTapped(_ sender: UIButton) {
        guard let cell = sender.superview as? UITableViewCell,
              let indexPath = tableView.indexPath(for: cell) else { return }

        let item = items[indexPath.row]
        viewModel.downloadVideo(item: item, context: context)
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let item = items[indexPath.row]
        let detailVC = VideoDetailViewController(item: item)
        navigationController?.pushViewController(detailVC, animated: true)
    }
    private func updateCellProgress(videoID: String, progress: Double) {
        guard let index = items.firstIndex(where: { $0.video_id == videoID }) else { return }
        let indexPath = IndexPath(row: index, section: 0)

        if let cell = tableView.cellForRow(at: indexPath) {
            if progress < 1.0 {
                // Update progress view
                if let progressView = cell.accessoryView as? UIProgressView {
                    progressView.progress = Float(progress)
                } else {
                    let progressView = UIProgressView(progressViewStyle: .default)
                    progressView.progress = Float(progress)
                    cell.accessoryView = progressView
                }
            } else {
                // Download completed, update the cell's accessory view
                cell.accessoryView = nil
                cell.detailTextLabel?.text = "Download Completed"
            }
        }
    }


}
